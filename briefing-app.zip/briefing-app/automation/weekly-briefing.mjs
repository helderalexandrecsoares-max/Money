// weekly-briefing.mjs
// Corre as 4 pesquisas de mercado e envia o resultado por email.
// Precisa de Node 18+ (tem fetch nativo) e dos pacotes: nodemailer
//
// Variáveis de ambiente necessárias (ver README.md):
//   ANTHROPIC_API_KEY
//   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS
//   MAIL_TO   (para quem enviar o briefing)

import nodemailer from "nodemailer";

const CATEGORIES = [
  {
    id: "products",
    label: "Produtos virais / emergentes",
    prompt: `Pesquisa na web informação atual sobre produtos físicos de consumo que estão a viralizar ou a crescer rapidamente em vendas globalmente agora, com potencial para revenda por um pequeno negócio online. Devolve APENAS um array JSON, sem texto antes ou depois, sem markdown, no formato:
[{"title":"nome do produto/categoria","description":"1-2 frases explicando porque está em alta e o potencial de margem","tag":"VIRAL ou EMERGENTE ou SAZONAL","score":1-5,"source_name":"nome da fonte","source_url":"url real"}]
Devolve 3 a 4 itens, os mais atuais e específicos possível.`
  },
  {
    id: "ideas",
    label: "Negócios que faltam em Portugal",
    prompt: `Pesquisa na web sobre modelos de negócio, serviços ou conceitos de retalho/e-commerce que já são populares noutros países mas ainda não existem ou são raros em Portugal. Devolve APENAS um array JSON, sem texto antes ou depois, sem markdown:
[{"title":"nome do conceito","description":"1-2 frases: o que é e porque poderia funcionar em Portugal","tag":"POR EXPLORAR ou NICHO","score":1-5,"source_name":"nome da fonte","source_url":"url real"}]
Devolve 3 a 4 itens.`
  },
  {
    id: "trends",
    label: "Tendências — capitais europeias",
    prompt: `Pesquisa na web sobre tendências de consumo e vendas retalho atuais em capitais europeias (Lisboa, Madrid, Paris, Berlim, Amesterdão, etc). Foca-te em categorias de produto ou hábitos de compra em crescimento. Devolve APENAS um array JSON, sem texto antes ou depois, sem markdown:
[{"title":"tendência","description":"1-2 frases sobre a tendência e em que cidade(s) é mais forte","tag":"CRESCIMENTO ou DECLÍNIO","score":1-5,"source_name":"nome da fonte","source_url":"url real"}]
Devolve 3 a 4 itens.`
  },
  {
    id: "invest",
    label: "Sinais comerciais / investimento",
    prompt: `Pesquisa na web notícias recentes sobre setores, startups ou categorias de produto a receber investimento significativo ou crescimento comercial forte, relevante para decidir onde investir tempo ou dinheiro num pequeno negócio. Devolve APENAS um array JSON, sem texto antes ou depois, sem markdown:
[{"title":"setor/empresa/movimento","description":"1-2 frases sobre o sinal comercial e porque importa","tag":"FINANCIAMENTO ou CRESCIMENTO","score":1-5,"source_name":"nome da fonte","source_url":"url real"}]
Devolve 3 a 4 itens.`
  }
];

async function runCategory(cat) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1200,
      messages: [{ role: "user", content: cat.prompt }],
      tools: [{ type: "web_search_20250305", name: "web_search" }]
    })
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`API falhou (${cat.id}): ${res.status} ${errText}`);
  }

  const data = await res.json();
  const text = (data.content || [])
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n")
    .trim()
    .replace(/^```json/i, "")
    .replace(/^```/, "")
    .replace(/```$/, "")
    .trim();

  try {
    return JSON.parse(text);
  } catch (e) {
    console.error(`Não consegui interpretar JSON de ${cat.id}:`, text);
    return [];
  }
}

function renderCategoryHtml(cat, items) {
  if (!items.length) {
    return `<h2 style="font-family:monospace;color:#8a7d68;">${cat.label}</h2><p style="color:#8a7d68;">Sem resultados desta vez.</p>`;
  }
  const rows = items
    .map(
      (it) => `
      <div style="border-left:3px solid #FFB000;padding:8px 14px;margin:10px 0;background:#181209;">
        <div style="font-size:10px;letter-spacing:1px;color:#5EEAD4;font-family:monospace;">${(it.tag || "").toUpperCase()} — SINAL ${it.score || "?"}/5</div>
        <div style="font-weight:600;font-size:15px;color:#F5EFE6;margin:4px 0;">${it.title || ""}</div>
        <div style="font-size:13px;color:#cfc6b8;line-height:1.5;">${it.description || ""}</div>
        ${it.source_url ? `<div style="font-size:11px;margin-top:4px;"><a href="${it.source_url}" style="color:#8a7d68;">${it.source_name || "fonte"}</a></div>` : ""}
      </div>`
    )
    .join("");
  return `<h2 style="font-family:monospace;color:#FFB000;font-size:14px;letter-spacing:1px;text-transform:uppercase;border-bottom:1px solid #3a2e1a;padding-bottom:6px;">${cat.label}</h2>${rows}`;
}

async function main() {
  console.log("A gerar briefing semanal...");
  const sections = [];
  for (const cat of CATEGORIES) {
    console.log(`→ ${cat.label}`);
    const items = await runCategory(cat);
    sections.push(renderCategoryHtml(cat, items));
  }

  const dateStr = new Date().toLocaleDateString("pt-PT", { day: "2-digit", month: "long", year: "numeric" });
  const html = `
  <div style="background:#0C0A08;padding:24px;font-family:sans-serif;">
    <div style="font-family:monospace;color:#FFB000;font-size:11px;letter-spacing:2px;">SITREP // MARKET SCAN</div>
    <h1 style="font-family:monospace;color:#F5EFE6;font-size:22px;margin:6px 0 4px;">Briefing de Mercado — ${dateStr}</h1>
    <p style="color:#8a7d68;font-size:12px;margin-bottom:20px;">Informação recolhida automaticamente. Confirma sempre as fontes antes de investir.</p>
    ${sections.join("<br>")}
  </div>`;

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });

  await transporter.sendMail({
    from: process.env.SMTP_USER,
    to: process.env.MAIL_TO,
    subject: `Briefing de Mercado — ${dateStr}`,
    html
  });

  console.log("Email enviado com sucesso.");
}

main().catch((err) => {
  console.error("Falhou:", err);
  process.exit(1);
});
