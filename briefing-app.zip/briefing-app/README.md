# SITREP — Briefing de Mercado

Duas partes neste pacote:

1. **App para o telemóvel** (pasta raiz: `index.html`, `manifest.json`, `sw.js`, `icons/`) — instalas como app, sem precisar de `.apk`.
2. **Automação semanal por email** (pasta `automation/`) — corre sozinha todas as segundas-feiras, grátis, no GitHub.

---

## Parte 1 — Instalar a app no telemóvel (sem `.apk`)

Um `.apk` real precisa de ser compilado com o Android SDK e assinado digitalmente — não é possível gerar isso sem um ambiente de build próprio. Em alternativa, esta app é uma **PWA** (Progressive Web App): instala-se no telemóvel como uma app normal, com ícone no ecrã principal, sem passar pela Play Store nem precisar de `.apk`.

**Passos:**

1. Precisas de alojar estes ficheiros online (tem de ser https — não funciona a abrir o ficheiro diretamente do telemóvel). A forma mais simples e grátis:
   - Cria uma conta em [github.com](https://github.com) (se ainda não tiveres)
   - Cria um repositório novo, carrega estes ficheiros (`index.html`, `manifest.json`, `sw.js`, pasta `icons/`)
   - Vai a **Settings → Pages** do repositório, ativa o GitHub Pages
   - Em ~1 minuto tens um link tipo `https://teunome.github.io/repo/`
2. Abre esse link no telemóvel (Chrome, no Android)
3. Vai ao menu (⋮) → **"Adicionar ao ecrã principal"** / **"Instalar app"**
4. Fica com ícone próprio, abre em ecrã inteiro, como uma app instalada

Se preferires, também posso ajudar-te a fazer isto via **Netlify** ou **Vercel** (drag-and-drop, sem sequer precisar de saber Git) — diz-me e explico esse caminho em vez do GitHub Pages.

---

## Parte 2 — Briefing semanal automático por email

Isto corre no GitHub Actions (gratuito para uso pessoal), sem precisares de servidor próprio ligado 24/7.

### O que precisas de ter:

1. **Uma chave de API da Anthropic**
   - Cria conta em [console.anthropic.com](https://console.anthropic.com)
   - Gera uma API key em "API Keys"
   - Nota: isto é pago por uso (não é o mesmo plano do claude.ai) — para 4 pesquisas por semana, o custo é muito baixo (poucos cêntimos por mês)

2. **Uma conta de email para enviar** (pode ser Gmail)
   - Se usares Gmail: ativa a "verificação em 2 passos" e depois cria uma **"palavra-passe de aplicação"** em myaccount.google.com/apppasswords — usa essa palavra-passe, não a tua password normal
   - `SMTP_HOST` = smtp.gmail.com
   - `SMTP_PORT` = 587
   - `SMTP_USER` = o teu email Gmail
   - `SMTP_PASS` = a palavra-passe de aplicação gerada

### Passos:

1. Cria um repositório no GitHub e carrega a pasta `automation/` (com o `.github/workflows/` incluído)
2. No repositório: **Settings → Secrets and variables → Actions → New repository secret**, e cria estes 5 secrets:
   - `ANTHROPIC_API_KEY`
   - `SMTP_HOST`
   - `SMTP_PORT`
   - `SMTP_USER`
   - `SMTP_PASS`
   - `MAIL_TO` (o email para onde queres receber o briefing)
3. Pronto — corre sozinho todas as segundas às 08:00 UTC. Podes também testar manualmente: aba **Actions** do repositório → escolhe "Briefing Semanal de Mercado" → **Run workflow**

### Para mudar o horário

No ficheiro `.github/workflows/weekly-briefing.yml`, a linha `cron: "0 8 * * 1"` controla quando corre (formato: minuto hora dia-do-mês mês dia-da-semana, em UTC). Por exemplo `"0 7 * * 1"` corre às 08:00 em Portugal no verão.

---

## Limitações a ter em conta

- O GitHub Actions grátis tem um limite de minutos por mês para contas privadas — para 1 execução semanal isto está muito longe do limite
- Os resultados dependem do que a pesquisa web encontra naquele momento — não é uma fonte de dados garantida ou oficial
- Isto dá-te sinais para investigar, não recomendações de investimento
